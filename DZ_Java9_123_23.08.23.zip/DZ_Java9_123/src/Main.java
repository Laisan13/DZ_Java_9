import java.time.LocalDate;
import java.util.Arrays;

public class Main {


    public static void main(String[] args) {
        //Создайте массив из 8 элементов.
        // В массиве должны храниться даты (класс LocalDate).
        // Чтобы создать элемент LocalDate используйте метод LocalDate.of(год, месяц, день),
        // где год, месяц и день – целые числа.
        //Выведите массив в консоль.
        LocalDate[] dates = {
                LocalDate.of(2019, 12, 13),
                LocalDate.of(2020, 1, 20),
                LocalDate.of(2021, 3, 14),
                LocalDate.of(2022, 10, 1),
                LocalDate.of(2023, 3, 15),
                LocalDate.of(2018, 1, 30),
                LocalDate.of(2019, 6, 10),
                LocalDate.of(2023, 4, 13)
        };

        System.out.println(Arrays.toString(dates));
        System.out.println();

        //2.Напишите метод, который отсортирует массив дат по году. В
        // Выведите массив в консоль
        System.out.println(Arrays.toString(sortArrayByCountingMethod(dates)));
        System.out.println();
        //3 Напишите метод, который отсортирует массив дат по дню месяца. Выведите массив в консоль.
        System.out.println(Arrays.toString(sortArrayByCountingMethodOfMonth(dates)));




    }
    private static void swapValues(LocalDate[] array, int index1, int index2) {
        LocalDate temp = array[index1];
        array[index1] = array[index2];
        array[index2] = temp;
    }


    private static LocalDate[] sortArrayByCountingMethod(LocalDate[] dates) {

        boolean isSorted = false;

        while (!isSorted) {
            isSorted = true;
            for (int i = 0; i < dates.length - 1; i++) {
                if (dates[i].getYear() > dates[i + 1].getYear()) {
                    swapValues(dates, i, i + 1);
                    isSorted = false;
                }
            }
        }
        return dates;
    }
    private static LocalDate[] sortArrayByCountingMethodOfMonth(LocalDate[] dates) {

        boolean isSorted = false;
        LocalDate[] datesTemp = new LocalDate[1];


        while (!isSorted) {
            isSorted = true;
            for (int i = 0; i < dates.length - 1; i++) {
                if (dates[i].getMonthValue() > dates[i + 1].getMonthValue()) {
                    swapValues(dates, i, i + 1);
                    isSorted = false;
                }
            }
        }
        return dates;
    }




}








